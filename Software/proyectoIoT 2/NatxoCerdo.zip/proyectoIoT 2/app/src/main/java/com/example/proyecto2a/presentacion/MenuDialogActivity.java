package com.example.proyecto2a.presentacion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.proyecto2a.R;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import java.util.Locale;

public class MenuDialogActivity extends AppCompatActivity {
    private TextView nombreLugar;
    double latitud;
    double longitud;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_menu_dialog);
        nombreLugar = (TextView) findViewById(R.id.TituloLugar);
        String nombre = getIntent().getStringExtra("nombre");
        latitud =getIntent().getDoubleExtra("lat", 0);
        longitud =getIntent().getDoubleExtra("long", 0);
        LatLng pos = new LatLng(latitud, longitud);
        nombreLugar.setText(nombre);
        //Consulta a bbdd para cargar las estaciones
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        //db.collection("estaciones").whereEqualTo("pos", pos).whereEqualTo("ubicacion", nombre).get("pos");

    }



    public void googleMaps(View view) {
        String url = "geo:";
        url += latitud + "," + longitud;
        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", latitud,longitud);
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse(uri));
        startActivity(intent);
    }
    public void cerrar(View view) {
        finish();
    }


}
