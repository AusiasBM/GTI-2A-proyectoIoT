package com.example.proyecto2a.presentacion;

import android.app.Activity;
import android.os.Bundle;

import com.example.proyecto2a.R;

public class InfoActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_registro);
    }
}
